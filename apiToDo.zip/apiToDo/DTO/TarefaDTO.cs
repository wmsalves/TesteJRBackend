﻿namespace apiToDo.DTO
{
    public class TarefaDTO
    {
        public int ID_TAREFA { get; set; }
        public string DS_TAREFA { get; set; }

    }
}
